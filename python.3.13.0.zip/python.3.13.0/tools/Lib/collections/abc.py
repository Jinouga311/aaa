import _collections_abc
import sys
sys.modules[__name__] = _collections_abc
